/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author jose.roblesbastidas
 */
public class Properties {
    public static boolean debug = false;
    public void setdebuggable(boolean b){
        debug = b;
    }

    public static class debug {

        public debug(boolean b) {
            debug = b;
        }
    }
}
